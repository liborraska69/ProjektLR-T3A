using System;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PiskvorkyApp
{
    public enum Hrac { Nikdo, X, O }

    public class LogikaPiskvorek
    {
        public Hrac[,] herniPole = new Hrac[3, 3];
        public Hrac aktualniHrac;
        public bool hrajemeProtiPC = false;

        public LogikaPiskvorek()
        {
            ResetujHru();
        }

        public void ResetujHru()
        {
            for (int r = 0; r < 3; r++)
                for (int s = 0; s < 3; s++)
                    herniPole[r, s] = Hrac.Nikdo;

            aktualniHrac = Hrac.X;
        }

        public bool ZkusTah(int r, int s)
        {
            if (herniPole[r, s] != Hrac.Nikdo) return false;

            herniPole[r, s] = aktualniHrac;

            if (aktualniHrac == Hrac.X) aktualniHrac = Hrac.O;
            else aktualniHrac = Hrac.X;

            return true;
        }

        public Hrac KdoVyhral()
        {
            for (int i = 0; i < 3; i++)
            {
                if (herniPole[i, 0] != Hrac.Nikdo && herniPole[i, 0] 
                    == herniPole[i, 1] && herniPole[i, 1] == herniPole[i, 2])
                    return herniPole[i, 0];
                if (herniPole[0, i] != Hrac.Nikdo && herniPole[0, i]
                    == herniPole[1, i] && herniPole[1, i] == herniPole[2, i])
                    return herniPole[0, i];
            }
            if (herniPole[0, 0] != Hrac.Nikdo && herniPole[0, 0]
                == herniPole[1, 1] && herniPole[1, 1] == herniPole[2, 2])
                return herniPole[0, 0];
            if (herniPole[0, 2] != Hrac.Nikdo && herniPole[0, 2]
                == herniPole[1, 1] && herniPole[1, 1] == herniPole[2, 0])
                return herniPole[0, 2];

            return Hrac.Nikdo;
        }

        public bool JePlno()
        {
            for (int r = 0; r < 3; r++)
                for (int s = 0; s < 3; s++)
                    if (herniPole[r, s] == Hrac.Nikdo) return false;
            return true;
        }

        public Point TahPocitace()
        {
            Random nahoda = new Random();
            List<Point> volnaMista = new List<Point>();

            for (int r = 0; r < 3; r++)
                for (int s = 0; s < 3; s++)
                    if (herniPole[r, s] == Hrac.Nikdo) volnaMista.Add(new Point(r, s));

            if (volnaMista.Count > 0) return volnaMista[nahoda.Next(volnaMista.Count)];
            return new Point(-1, -1);
        }
    }

    public partial class Form1 : Form
    {
        private LogikaPiskvorek hra = new LogikaPiskvorek();
        private Button[,] tlacitka = new Button[3, 3];
        private Label popisekStavu = new Label();
        private MenuStrip menuLista = new MenuStrip();

        public Form1()
        {
            NastavVzhled();
        }

        private void NastavVzhled()
        {
            this.Text = "Piškvorky";
            this.Size = new Size(400, 550);
            this.BackColor = Color.Black;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            menuLista.BackColor = Color.FromArgb(30, 30, 30);
            menuLista.ForeColor = Color.White;

            ToolStripMenuItem polozkaMenu = new ToolStripMenuItem(" MENU ");
            polozkaMenu.ForeColor = Color.White;

            var hracHrac = new ToolStripMenuItem("Hrát proti hráči", null, (s, e) => { hra.hrajemeProtiPC = false; NovaHra(); });
            var hracPC = new ToolStripMenuItem("Hrát proti PC", null, (s, e) => { hra.hrajemeProtiPC = true; NovaHra(); });
            var napoveda = new ToolStripMenuItem("Nápověda", null, (s, e) => ZobrazNapovedu());
            var zavrit = new ToolStripMenuItem("Zavřít", null, (s, e) => Application.Exit());

            polozkaMenu.DropDownItems.Add(hracHrac);
            polozkaMenu.DropDownItems.Add(hracPC);
            polozkaMenu.DropDownItems.Add(napoveda);
            polozkaMenu.DropDownItems.Add(new ToolStripSeparator());
            polozkaMenu.DropDownItems.Add(zavrit);
            menuLista.Items.Add(polozkaMenu);

            popisekStavu.Dock = DockStyle.Bottom;
            popisekStavu.Height = 60;
            popisekStavu.TextAlign = ContentAlignment.MiddleCenter;
            popisekStavu.ForeColor = Color.White;
            popisekStavu.Font = new Font("Segoe UI", 11, FontStyle.Bold);

            TableLayoutPanel mrizka = new TableLayoutPanel {RowCount = 3, ColumnCount = 3, Dock = DockStyle.Fill, Padding = new Padding(20)};

            for (int i = 0; i < 3; i++)
            {
                mrizka.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
                mrizka.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33f));
                for (int j = 0; j < 3; j++)
                {
                    Button b = new Button
                    {
                        Dock = DockStyle.Fill,
                        FlatStyle = FlatStyle.Flat,
                        BackColor = Color.FromArgb(25, 25, 25),
                        ForeColor = Color.White,
                        Font = new Font("Arial", 32, FontStyle.Bold),
                        Tag = new Point(i, j)
                    };
                    b.FlatAppearance.BorderColor = Color.White;
                    b.Click += KlikNaNeco;
                    tlacitka[i, j] = b;
                    mrizka.Controls.Add(b, j, i);
                }
            }

            this.Controls.Add(mrizka);
            this.Controls.Add(popisekStavu);
            this.Controls.Add(menuLista);
            this.MainMenuStrip = menuLista;

            AktualizujObrazovku();
        }

        private void ZobrazNapovedu()
        {
            string pravidla = "Pravidla hry Piškvorky:\n\n" +
                             "1. Hra se hraje na poli 3x3.\n" +
                             "2. Hráči střídavě umisťují své symboly (X a O).\n" +
                             "3. Vítězem se stává hráč, který jako první vytvoří nepřerušenou řadu tří svých symbolů.\n" +
                             "4. Řada může být vodorovná, svislá nebo šikmá (diagonální).\n" +
                             "5. Pokud je celé pole zaplněno a nikdo nevyhrál, hra končí remízou.";

            MessageBox.Show(pravidla, "Jak vyhrát");
        }

        private void KlikNaNeco(object sender, EventArgs e)
        {
            Button stisknuteTlacitko = (Button)sender;
            Point koordinaty = (Point)stisknuteTlacitko.Tag;

            if (hra.ZkusTah(koordinaty.X, koordinaty.Y))
            {
                AktualizujObrazovku();
                if (ZkontrolovatKonec()) return;

                if (hra.hrajemeProtiPC && hra.aktualniHrac == Hrac.O)
                {
                    Point tahPC = hra.TahPocitace();
                    if (tahPC.X != -1)
                    {
                        hra.ZkusTah(tahPC.X, tahPC.Y);
                        AktualizujObrazovku();
                        ZkontrolovatKonec();
                    }
                }
            }
        }

        private void AktualizujObrazovku()
        {
            for (int r = 0; r < 3; r++)
                for (int s = 0; s < 3; s++)
                    tlacitka[r, s].Text = hra.herniPole[r, s] == Hrac.Nikdo ? "" : hra.herniPole[r, s].ToString();

            string rezim = hra.hrajemeProtiPC ? "Proti PC" : "Dva hráči";
            popisekStavu.Text = $"{rezim} | Na řadě: {hra.aktualniHrac}";
        }

        private bool ZkontrolovatKonec()
        {
            Hrac vitez = hra.KdoVyhral();
            if (vitez != Hrac.Nikdo || hra.JePlno())
            {
                string zprava = (vitez != Hrac.Nikdo) ? "Vítěz: " + vitez : "Remíza!";
                MessageBox.Show(zprava, "Konec hry");
                NovaHra();
                return true;
            }
            return false;
        }

        private void NovaHra()
        {
            hra.ResetujHru();
            AktualizujObrazovku();
        }
    }
}